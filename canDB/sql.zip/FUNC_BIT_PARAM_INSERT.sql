-- 04/12/2015, 05/21/2016
-- Define bits in second byte of group polling msg
-- ALSO, define bits in first byte of group polling msg
--
-- Each FUNCTION_TYPE has a bit assigned.
-- When the bit matches the bit in the group poll msg
--  and the the drum/group number matches in the first
--  byte, the function sends it measurement.
--
-- FUNC_BIT_PARAM_NAME varchar(48) PRIMARY KEY,
--   A unique name to refer to the bit/function
--
-- FUNC_BIT_PARAM_VAL varchar(24),
--   Bit specifies the function to respond to a poll msg
--
-- FUNCTION_TYPE varchar(24),
--
-- FORMAT varchar(24),
--  Format type for display purposes, e.g. java
--
-- DESCRIPTION varchar(128) NOT NULL UNIQUE
--  Unique description 
--
DELETE FROM FUNC_BIT_PARAM;
--
--                                 FUNC_BIT_PARAM_NAME      FUNC_BIT_PARAM_VAL FUNCTION_TYPE   FORMAT      DESCRIPTION 
INSERT INTO FUNC_BIT_PARAM VALUES ('POLL_FUNC_BIT_TENSION', 		'0x1',	'TENSION',	'%x',	'Function bit: 2nd byte of poll msg: TENSION');
INSERT INTO FUNC_BIT_PARAM VALUES ('POLL_FUNC_BIT_CABLE_ANGLE', 	'0x2',	'CABLE_ANGLE',	'%x',	'Function bit: 2nd byte of poll msg: CABLE_ANGLE');
INSERT INTO FUNC_BIT_PARAM VALUES ('POLL_FUNC_BIT_SHAFT_ODO_SPD', 	'0x4',	'SHAFT_ENCODER','%x',	'Function bit: 2nd byte of poll msg: shaft odometer & speed');
INSERT INTO FUNC_BIT_PARAM VALUES ('POLL_FUNC_BIT_TILT', 		'0x8',	'TILT_SENSE', 	'%x',	'Function bit: 2nd byte of poll msg: TILT');
--
-- First byte of group poll msg 
INSERT INTO FUNC_BIT_PARAM VALUES ('POLL_DO_NOT', 			'0x0',	'DUMMY'        ,'%x',	'No reply sent to poll msg');
INSERT INTO FUNC_BIT_PARAM VALUES ('POLL_DRUM_BIT_1', 			'0x1',	'SELECT_DRUM_1','%x',	'Selection bit: 1st byte of poll msg Drum #1');
INSERT INTO FUNC_BIT_PARAM VALUES ('POLL_DRUM_BIT_2', 			'0x2',	'SELECT_DRUM_2','%x',	'Selection bit: 1st byte of poll msg Drum #2');
INSERT INTO FUNC_BIT_PARAM VALUES ('POLL_DRUM_BIT_3', 			'0x4',	'SELECT_DRUM_4','%x',	'Selection bit: 1st byte of poll msg Drum #3');
INSERT INTO FUNC_BIT_PARAM VALUES ('POLL_DRUM_BIT_4', 			'0x8',	'SELECT_DRUM_8','%x',	'Selection bit: 1st byte of poll msg Drum #4');


