-- WINCHSTATE table
-- 05/31/2016
--
-- WINCHSTATE_NAME varchar(24) PRIMARY KEY,
--  Name of winch state
--
-- WINCHSTATE_CODE	NUMERIC UNIQUE,
--  Code that matches the name
--  Naming convention:
--  'SUPER_STATE_' = Upper 4 bits of a byte
--  'SUB_STATE_' = Lower 4 bits of a byte
--
-- DESCRIPTION varchar(128) NOT NULL UNIQUE
--  Good words that might mean something to someone. 
--
DELETE from WINCHSTATE;
--                 

--           WINCHSTATE_NAME      WINCHSTATE_CODE   DESCRIPTION
INSERT INTO WINCHSTATE VALUES ('SUPER_STATE_SAFE',	 0,	' Winchstate: Safe (idle)  ' );
INSERT INTO WINCHSTATE VALUES ('SUPER_STATE_PREP', 	 1,	' Winchstate: Prepartory somethings ' );
INSERT INTO WINCHSTATE VALUES ('SUPER_STATE_ARM' , 	 2,	' Winchstate: Motor controller connected to battery string ' );
INSERT INTO WINCHSTATE VALUES ('SUPER_STATE_PROFILE',  	 3,	' Winchstate: Early launch tension profile used ' );
INSERT INTO WINCHSTATE VALUES ('SUPER_STATE_TAPER', 	 4,	' Winchstate: Tapering tension to limit speed before rotation ' );
INSERT INTO WINCHSTATE VALUES ('SUPER_STATE_CLIMB', 	 5,	' Winchstate: Glider in climb state ' );
INSERT INTO WINCHSTATE VALUES ('SUPER_STATE_RECOVERY', 	 6,	' Winchstate: Glider released and chute recovery ' );
INSERT INTO WINCHSTATE VALUES ('SUPER_STATE_RETRIEVE',	 7,	' Winchstate: Cable being towed back to launch position ' );

INSERT INTO WINCHSTATE VALUES ('SUPER_STATE_ABORT', 	10,	' Winchstate: Immediate shutdown of current launch ' );
INSERT INTO WINCHSTATE VALUES ('SUPER_STATE_STOP', 	11,	' Winchstate: Stopped??? ' );

INSERT INTO WINCHSTATE VALUES ('SUPER_STATE_CAL', 	15,	' Winchstate: Calibration ' );

