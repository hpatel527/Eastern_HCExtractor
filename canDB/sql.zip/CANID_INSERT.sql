-- CANID table associates a CANID "name" with a hex value and usage type
-- 07/10/2015
--
-- CANID_NAME is used rather than a hex value, allowing changes to hex assignments without changing a program.
-- CANID_NAME varchar(48) PRIMARY KEY,
--  Each CAN ID is given a uniqute name.  A Java program produces a .h file with #define that connects the name with 
--  the hex code.  Programs are written using the name so that if there are changes in the hex code the source
--  code does not need to be changed and only recompiling is required.
--
-- CANID_HEX varchar(8) NOT NULL UNIQUE,
--  This is the hex code for the CAN ID left justified as defined in the STM32 Reference Manual, and as follows--
--
--  Bits in 32b word for CAN ID--
--
--   If a standard 11 bit CAN ID:
--      31:21 And, IDE (bit 2) is zero
--   If an extended CAN ID:
--      31:03 And, IDE (bit 2) is one
--
--   Lower value CAN IDs have higher CAN priority
--
--   Bit 1 RTR: Remote transmission request
--      0: Data frame
--      1: Remote frame
--
--   Bit 0 Reserved.  Used for triggering hardware to xmit
--
--
-- CANID_TYPE varchar(24) NOT NULL,
--  A clue as to where this CAN ID might be used
--  (This column may not be needed, i.e. redundant.)
--
-- DESCRIPTION varchar(128) NOT NULL UNIQUE
--  Clever words for further eludication and identification (must be unique).  Since the description field is unique
--  a search can be made using the field.
--
-- Rebuild the table by--
-- Delete all the current values:
DELETE from CANID;
-- Then add everything that follows:
--                         CANID_NAME                    CANID_HEX   CANID_TYPE         DESCRIPTION
INSERT INTO CANID VALUES ('CANID_MSG_TENSION_0',	'48000000', 'TENSION_a', 	'Tension_0: Default measurement canid');
INSERT INTO CANID VALUES ('CANID_MSG_TENSION_a11',	'38000000', 'TENSION_a', 	'Tension_a11: Drum 1 calibrated tension, polled by time msg');
INSERT INTO CANID VALUES ('CANID_MSG_TENSION_a21',	'38200000', 'TENSION_a', 	'Tension_a12: Drum 1 calibrated tension, polled by time msg');
INSERT INTO CANID VALUES ('CANID_MSG_TENSION_a12',	'38400000', 'TENSION_a', 	'Tension_a21: Drum 2 calibrated tension, polled by time msg');
INSERT INTO CANID VALUES ('CANID_MSG_TENSION_a22',	'38600000', 'TENSION_a', 	'Tension_a22: Drum 2 calibrated tension, polled by time msg');
INSERT INTO CANID VALUES ('CANID_MSG_TENSION_2',	'38800000', 'TENSION_2', 	'Tension_2: calibrated tension, polled by time msg');

INSERT INTO CANID VALUES ('CANID_TST_TENSION_a11',	'F800010C', 'TENSION_a', 	'Tension_a11: TESTING java program generation of idx_v_val.c');
INSERT INTO CANID VALUES ('CANID_TST_TENSION_a12',	'F800020C', 'TENSION_a', 	'Tension_a12: TESTING java program generation of idx_v_val.c');
INSERT INTO CANID VALUES ('CANID_TST_TENSION_a21',	'F800030C', 'TENSION_a', 	'Tension_a21: TESTING java program generation of idx_v_val.c');

-- This group is for testing programs and boards
INSERT INTO CANID VALUES ('CANID_CMD_TENSION_a1W',	'05C0003C', 'TENSION_a', 	'Tension_a: 1W Command code: [0] command code, [1]-[8] depends on code');
INSERT INTO CANID VALUES ('CANID_CMD_TENSION_a2W',	'05C0004C', 'TENSION_a', 	'Tension_a: 2W Command code: [0] command code, [1]-[8] depends on code');

INSERT INTO CANID VALUES ('CANID_CMD_TENSION_a11',	'05C0000C', 'TENSION_a', 	'Tension_a11: Command code: [0] command code, [1]-[8] depends on code');
INSERT INTO CANID VALUES ('CANID_CMD_TENSION_a21',	'05E0000C', 'TENSION_a', 	'Tension_a21: Command code: [0] command code, [1]-[8] depends on code');
INSERT INTO CANID VALUES ('CANID_CMD_TENSION_0',	'E8000000', 'TENSION_0', 	'Tension_0: Default command canid');
INSERT INTO CANID VALUES ('CANID_CMD_TENSION_a0X',	'F800001C', 'TENSION_a',	'Tension_a:  1 AD7799 VE POD TESTING (hence 0) 0' );
INSERT INTO CANID VALUES ('CANID_CMD_TENSION_a1X',	'F800002C', 'TENSION_a',	'Tension_a:  2 AD7799 VE POD TESTING (hence X) 1' );
INSERT INTO CANID VALUES ('CANID_CMD_TENSION_a2X',	'F800003C', 'TENSION_a',	'Tension_a2: 2 AD7799 VE POD TESTING (hence X) 1' );
INSERT INTO CANID VALUES ('CANID_CMD_TENSION_a1Y',	'F800004C', 'TENSION_a',	'Tension_a:  1 AD7799 VE POD TESTING (hence Y) 2' );
INSERT INTO CANID VALUES ('CANID_CMD_TENSION_a1Z',	'F800005C', 'TENSION_a',	'Tension_a:  2 AD7799 VE POD TESTING (hence Z) 3' );
INSERT INTO CANID VALUES ('CANID_CMD_TENSION_a2Z',	'F800006C', 'TENSION_a',	'Tension_a2: 2 AD7799 VE POD TESTING (hence Z) 3' );
INSERT INTO CANID VALUES ('CANID_CMD_TENSION_a1G',	'F800007C', 'TENSION_a',	'Tension_a:  2 AD7799 VE POD GSM 1st board sent (_16)' );
INSERT INTO CANID VALUES ('CANID_CMD_TENSION_a2G',	'F800008C', 'TENSION_a',	'Tension_a2: 2 AD7799 VE POD GSM 1st board sent (_16)' );
INSERT INTO CANID VALUES ('CANID_CMD_TENSION_2',	'05C0005C', 'TENSION_2', 	'Tension_2: Tension_2: Command code: [0] command code, [1]-[8] depends on code');

INSERT INTO CANID VALUES ('CANID_MOTOR_1',		'2D000000', 'MOTOR_1', 		'MOTOR_1: Motor speed');

INSERT INTO CANID VALUES ('CANID_CMD_CABLE_ANGLE_0',	'06000000', 'CABLE_ANGLE_0', 	'Cable_Angle0: Default measurement canid');
INSERT INTO CANID VALUES ('CANID_CMD_CABLE_ANGLE_1',	'06200000', 'CABLE_ANGLE_1', 	'Cable_Angle1: [0] command code, [1]-[8] depends on code');
INSERT INTO CANID VALUES ('CANID_MSG_CABLE_ANGLE_1',	'3A000000', 'CABLE_ANGLE_1', 	'Cable_Angle1: for drum #1');
INSERT INTO CANID VALUES ('CANID_MSG_CABLE_ANGLE_1_ALARM','2B000000', 'CABLE_ANGLE_1',	'Cable_Angle1: unreliable for drum #1');

INSERT INTO CANID VALUES ('CANID_CMD_ENGINE_SENSOR',	'80600000', 'ENGINE_SENSOR', 	'Engine: code: [0] command code, [1]-[8] depends on code');
INSERT INTO CANID VALUES ('CANID_HB_ENG_RPMMANIFOLD',	'40600000', 'ENGINE_SENSOR', 	'Engine: rpm:manifold pressure');
INSERT INTO CANID VALUES ('CANID_HB_ENG_TEMP',		'70600000', 'ENGINE_SENSOR', 	'Engine: thermistor converted to temp');
INSERT INTO CANID VALUES ('CANID_HB_ENG_THERMTHROTL',	'60600000', 'ENGINE_SENSOR', 	'Engine: thermistor:throttle pot');
INSERT INTO CANID VALUES ('CANID_HB_ENG_THROTTLE',	'50600000', 'ENGINE_SENSOR', 	'Engine: throttle');

INSERT INTO CANID VALUES ('CANID_CMD_TIMESYNC',		'C1C00000', 'TIMESYNC', 	'Time: CANID Command GPS');
INSERT INTO CANID VALUES ('CANID_HB_FIX_HT_TYP_NSAT',	'B1C00000', 'TIMESYNC', 	'Time: GPS winch fix: heigth:type fix:number sats');
INSERT INTO CANID VALUES ('CANID_HB_FIX_LATLON',	'A1C00000', 'TIMESYNC', 	'Time: GPS winch fix: lattitude:longitude');
INSERT INTO CANID VALUES ('CANID_HB_LG_ER1',		'D1C00004', 'TIMESYNC', 	'Time: 1st code  CANID-UNITID_CO_OLI GPS checksum error');
INSERT INTO CANID VALUES ('CANID_HB_LG_ER2',		'D1C00014', 'TIMESYNC', 	'Time: 2nd code  CANID-UNITID_CO_OLI GPS Fix error');
INSERT INTO CANID VALUES ('CANID_HB_LG_ER3',		'D1C00024', 'TIMESYNC', 	'Time: 3rd code  CANID-UNITID_CO_OLI GPS Time out of step');
INSERT INTO CANID VALUES ('CANID_HB_TIMESYNC',		'00200000', 'TIMESYNC', 	'Time: GPS time sync distribution msg');

INSERT INTO CANID VALUES ('CANID_MC_DRUM_SELECT',	'D0800814', 'MC', 		'MC: Drum selection');
INSERT INTO CANID VALUES ('CANID_HB_MC_MOTOR_1_KPALIVE','A0800000', 'MC', 		'MC: Curtis Controller keepalive');
INSERT INTO CANID VALUES ('CANID_MC_REQUEST_PARAM',	'D0800824', 'MC', 		'MC: Request parameters from HC');
INSERT INTO CANID VALUES ('CANID_MC_CONTACTOR',		'23000000', 'MC',		'MC: Contactor OPEN/CLOSE');
INSERT INTO CANID VALUES ('CANID_MC_BRAKES',		'21000000', 'MC',		'MC: Brakes APPLY/RELEASE');
INSERT INTO CANID VALUES ('CANID_MC_GUILLOTINE',	'22000000', 'MC',		'MC: Fire guillotine');
INSERT INTO CANID VALUES ('CANID_MC_RQ_LAUNCH_PARAM',	'27000000', 'MC',		'MC: Fire request launch parameters');
INSERT INTO CANID VALUES ('CANID_MSG_TIME_POLL',	'20000000', 'MC', 		'MC: Time msg/Group polling');
INSERT INTO CANID VALUES ('CANID_MC_STATE',		'26000000', 'MC', 		'MC: Launch state msg');
INSERT INTO CANID VALUES ('CANID_MC_TORQUE',		'25800000', 'MC', 		'MC: Motor torque');

INSERT INTO CANID VALUES ('CANID_CP_CTL_RMT',		'29000000', 'CP', 		'Control Panel: Control lever remote');
INSERT INTO CANID VALUES ('CANID_CP_CTL_LCL',		'29200000', 'CP', 		'Control Panel: Control lever local');
INSERT INTO CANID VALUES ('CANID_CP_CTL_IN_RMT',	'24C00000', 'CP', 		'Control Panel: Control lever remote: input');
INSERT INTO CANID VALUES ('CANID_CP_CTL_IN_LCL',	'25000000', 'CP', 		'Control Panel: Control lever  local: input');
INSERT INTO CANID VALUES ('CANID_CP_CTL_OUT_RMT',	'2A000000', 'CP', 		'Control Panel: Control lever output');

INSERT INTO CANID VALUES ('CANID_SE2H_ADC2_HistA',	'D0800044', 'SHAFT_LOWERSHV',	'Shaft encoder: Lower sheave:SE2: ADC2 HistogramA tx: request count, switch buffers; rx send count');
INSERT INTO CANID VALUES ('CANID_SE2H_ADC2_HistB',	'D0800054', 'SHAFT_LOWERSHV', 	'Shaft encoder: Lower sheave:SE2: ADC2 HistogramB tx: bin number, rx: send bin count');
INSERT INTO CANID VALUES ('CANID_SE2H_ADC3_ADC2_RD',	'D0800064', 'SHAFT_LOWERSHV', 	'Shaft encoder: Lower sheave:SE2: ADC3 ADC2 readings readout');
INSERT INTO CANID VALUES ('CANID_SE2H_ADC3_HistA',	'D0800024', 'SHAFT_LOWERSHV', 	'Shaft encoder: Lower sheave:SE2: ADC3 HistogramA tx: request count, switch buffers. rx: send count');
INSERT INTO CANID VALUES ('CANID_SE2H_ADC3_HistB',	'D0800034', 'SHAFT_LOWERSHV', 	'Shaft encoder: Lower sheave:E2: ADC3 HistogramB tx: bin number, rx: send bin count');
INSERT INTO CANID VALUES ('CANID_SE2H_COUNTERnSPEED',	'30800000', 'SHAFT_LOWERSHV', 	'Shaft encoder: Lower sheave:SE2: (Lower sheave) Count and speed');
INSERT INTO CANID VALUES ('CANID_SE2H_ERROR1',		'D0800014', 'SHAFT_LOWERSHV', 	'Shaft encoder: Lower sheave:SE2: error1');
INSERT INTO CANID VALUES ('CANID_SE2H_ERROR2',		'D0800004', 'SHAFT_LOWERSHV', 	'Shaft encoder: Lower sheave:SE2: error2');
INSERT INTO CANID VALUES ('CANID_CMD_LOWERSHV',		'D0800000', 'SHAFT_LOWERSHV', 	'Shaft encoder: Lower sheave:SE2: Command CAN: send commands to subsystem');

INSERT INTO CANID VALUES ('CANID_SE3H_ADC2_HistA',	'D0A00044', 'SHAFT_UPPERSHV', 	'Shaft encoder: Upper sheave: SE3: ADC2 HistogramA tx: request count, switch buffers; rx send count');
INSERT INTO CANID VALUES ('CANID_SE3H_ADC2_HistB',	'D0A00054', 'SHAFT_UPPERSHV', 	'Shaft encoder: Upper sheave:SE3: ADC2 HistogramB tx: bin number, rx: send bin count');
INSERT INTO CANID VALUES ('CANID_SE3H_ADC3_ADC2_RD',	'D0A00064', 'SHAFT_UPPERSHV', 	'Shaft encoder: Upper sheave:SE3: ADC3 ADC2 readings readout');
INSERT INTO CANID VALUES ('CANID_SE3H_ADC3_HistA',	'D0A00024', 'SHAFT_UPPERSHV', 	'Shaft encoder: Upper sheave:SE3: ADC3 HistogramA tx: request count, switch buffers. rx: send count');
INSERT INTO CANID VALUES ('CANID_SE3H_ADC3_HistB',	'D0A00034', 'SHAFT_UPPERSHV', 	'Shaft encoder: Upper sheave:SE3: ADC3 HistogramB tx: bin number, rx: send bin count');
INSERT INTO CANID VALUES ('CANID_SE3H_COUNTERnSPEED',	'30A00000', 'SHAFT_UPPERSHV', 	'Shaft encoder: Upper sheave:SE3: (upper sheave) Count and Speed');
INSERT INTO CANID VALUES ('CANID_SE3H_ERROR1',		'D0A00014', 'SHAFT_UPPERSHV', 	'Shaft encoder: Upper sheave:SE3: error1');
INSERT INTO CANID VALUES ('CANID_SE3H_ERROR2',		'D0A00004', 'SHAFT_UPPERSHV', 	'Shaft encoder: Upper sheave:SE3: error2');
INSERT INTO CANID VALUES ('CANID_CMD_UPPERSHV',		'D0600000', 'SHAFT_UPPERSHV', 	'Shaft encoder: Upper sheave:SE3: Command CAN: send commands to subsystem');

INSERT INTO CANID VALUES ('CANID_SE4H_ADC2_HistA',	'D0400044', 'DRIVE_SHAFT', 	'Drive shaft: ADC2 HistogramA tx: request count, switch buffers; rx send count');
INSERT INTO CANID VALUES ('CANID_SE4H_ADC2_HistB',	'D0400054', 'DRIVE_SHAFT', 	'Drive shaft: ADC2 HistogramB tx: bin number, rx: send bin count');
INSERT INTO CANID VALUES ('CANID_SE4H_ADC3_ADC2_RD',	'D0400064', 'DRIVE_SHAFT', 	'Drive shaft: ADC3 ADC2 readings readout');
INSERT INTO CANID VALUES ('CANID_SE4H_ADC3_HistA',	'D0400024', 'DRIVE_SHAFT', 	'Drive shaft: ADC3 HistogramA tx: request count, switch buffers. rx: send count');
INSERT INTO CANID VALUES ('CANID_SE4H_ADC3_HistB',	'D0400034', 'DRIVE_SHAFT', 	'Drive shaft: ADC3 HistogramB tx: bin number, rx: send bin count');
INSERT INTO CANID VALUES ('CANID_CMD_DRIVE_SHAFT',	'D0400000', 'DRIVE_SHAFT', 	'Drive shaft: Command CAN: send commands to subsystem');
INSERT INTO CANID VALUES ('CANID_SE4H_COUNTERnSPEED',	'30400000', 'DRIVE_SHAFT', 	'Drive shaft: (drive shaft) count and speed');
INSERT INTO CANID VALUES ('CANID_SE4H_ERROR1',		'D0400014', 'DRIVE_SHAFT',	'Drive shaft: [2]elapsed_ticks_no_adcticks<2000 ct  [3]cic not in sync');
INSERT INTO CANID VALUES ('CANID_SE4H_ERROR2',		'D0400004', 'DRIVE_SHAFT', 	'Drive shaft: [0]encode_state er ct [1]adctick_diff<2000 ct');

INSERT INTO CANID VALUES ('CANID_TILT_ALARM',		'02800000', 'TILT_SENSE', 	'Tilt: alarm: Vector angle exceeds limit');
INSERT INTO CANID VALUES ('CANID_TILT_ANGLE',		'42E00000', 'TILT_SENSE', 	'Tilt: Calibrated angles (X & Y)');
INSERT INTO CANID VALUES ('CANID_TILT_XYZ',		'42800000', 'TILT_SENSE', 	'Tilt:Calibrated to angle: x,y,z tilt readings');
INSERT INTO CANID VALUES ('CANID_TILT_XYZ_CAL',		'FFFFFFCC', 'TILT_SENSE', 	'Tilt:CANID: Raw tilt ADC readings');
INSERT INTO CANID VALUES ('CANID_TILT_XYZ_RAW',		'4280000C', 'TILT_SENSE', 	'Tilt:Tilt:Raw tilt ADC readings');
INSERT INTO CANID VALUES ('CANID_CMD_TILT',		'42C00000', 'TILT_SENSE', 	'Tilt:Command CANID');

INSERT INTO CANID VALUES ('CANID_HB_GATEWAY',		'E0200000', 'GATEWAY',	 	'Gateway: Heartbeat');
INSERT INTO CANID VALUES ('CANID_HB_TENSION_0',		'E0400000', 'TENSION_0', 	'Tension_0: Heartbeat');
INSERT INTO CANID VALUES ('CANID_HB_TENSION_a11',	'E0600000', 'TENSION_a', 	'Tension_a11: Heartbeat');
INSERT INTO CANID VALUES ('CANID_HB_TENSION_a21',	'E0C00000', 'TENSION_a', 	'Tension_a21: Heartbeat');
INSERT INTO CANID VALUES ('CANID_HB_TENSION_a12',	'E0800000', 'TENSION_a', 	'Tension_a12: Heartbeat');
INSERT INTO CANID VALUES ('CANID_HB_CABLE_ANGLE_1',	'E0A00000', 'CABLE_ANGLE_1', 	'Cable_Angle_1: Heartbeat');

INSERT INTO CANID VALUES ('CANID_CMD_SANDBOX_1',	'28E00000', 'SANDBOX_1',	'HC: SANDBOX_1: Launch parameters');

INSERT INTO CANID VALUES ('CANID_CMD_YOGURT_1',		'29800000', 'YOGURT_1',		'Yogurt: YOGURT_1: Yogurt maker parameters');
INSERT INTO CANID VALUES ('CANID_MSG_YOGURT_1',		'29400000', 'YOGURT_1',		'Yogurt: YOGURT_1: Yogurt maker msgs');
INSERT INTO CANID VALUES ('CANID_HB_YOGURT_1',		'29600000', 'YOGURT_1',		'Yogurt: YOGURT_1: Heart-beats');


INSERT INTO CANID VALUES ('CANID_UNIT_2',		'00400000', 'UNIT_2', 		'Sensor unit: Drive shaft encoder');
INSERT INTO CANID VALUES ('CANID_UNIT_3',		'00600000', 'UNIT_3', 		'Sensor unit: Engine');
INSERT INTO CANID VALUES ('CANID_UNIT_4',		'00800000', 'UNIT_4', 		'Sensor unit: Lower sheave shaft encoder');
INSERT INTO CANID VALUES ('CANID_UNIT_5',		'00A00000', 'UNIT_5', 		'Sensor unit: Upper sheave shaft encoder');
INSERT INTO CANID VALUES ('CANID_UNIT_8',		'01000000', 'UNIT_8', 		'Sensor unit: Level wind');
INSERT INTO CANID VALUES ('CANID_UNIT_9',		'01200000', 'UNIT_9', 		'Sensor unit: XBee receiver #1');
INSERT INTO CANID VALUES ('CANID_UNIT_A',		'0140000C', 'UNIT_A', 		'Sensor unit: XBee receiver #2');
INSERT INTO CANID VALUES ('CANID_UNIT_B',		'0160000C', 'UNIT_B', 		'Display driver/console');
INSERT INTO CANID VALUES ('CANID_UNIT_C',		'0180000C', 'UNIT_C', 		'CAWs Olimex board');
INSERT INTO CANID VALUES ('CANID_UNIT_D',		'01A0000C', 'UNIT_D', 		'POD board sensor prototype ("6" marked on board)');
INSERT INTO CANID VALUES ('CANID_UNIT_E',		'01C0000C', 'UNIT_E', 		'Logger: sensor board w ublox gps & SD card');
INSERT INTO CANID VALUES ('CANID_UNIT_F',		'01E0000C', 'UNIT_F', 		'Tension_1 & Cable_angle_1 Unit');
INSERT INTO CANID VALUES ('CANID_UNIT_10',		'0200000C', 'UNIT_10', 		'Gateway: ');
INSERT INTO CANID VALUES ('CANID_UNIT_19',		'0280000C', 'UNIT_19', 		'Master Controller');
INSERT INTO CANID VALUES ('CANID_UNIT_11',		'02200000', 'UNIT_11', 		'Tension: 1 AD7799 VE POD brd 1');
INSERT INTO CANID VALUES ('CANID_UNIT_12',		'02400000', 'UNIT_12', 		'Tension: 2 AD7799 VE POD brd 2');
INSERT INTO CANID VALUES ('CANID_UNIT_13',		'02600000', 'UNIT_13', 		'Yogurt: Olimex board');
INSERT INTO CANID VALUES ('CANID_UNIT_14',		'02E00000', 'UNIT_14', 		'Tension: 1 AD7799 VE POD brd 3');
INSERT INTO CANID VALUES ('CANID_UNIT_15',		'02A00000', 'UNIT_15', 		'Tension: 2 AD7799 VE POD brd 4');
INSERT INTO CANID VALUES ('CANID_UNIT_16',		'02C00000', 'UNIT_16', 		'Tension: 2 AD7799 VE POD brd 5 GSM');

INSERT INTO CANID VALUES ('CANID_UNIT_99',		'FFFFFF14', 'UNIT_99', 		'Dummy for missing CAN IDs');
INSERT INTO CANID VALUES ('CANID_DUMMY',		'FFFFFFFC', 'UNIT_NU', 		'Dummy ID: Lowest priority possible (Not Used)');
INSERT INTO CANID VALUES ('CANID_MSG_DUMMY',		'FFFFFF16', 'ANY', 		'Dummy ID: Polled Msg dummy');

