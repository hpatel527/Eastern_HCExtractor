-- READINGS_LIST_INSERT.sql  Defines the readings by type of function.
-- 04/11/2015
--
-- READINGS_NAME (Unique name for value to be xmitted)
-- READINGS_CODE (Used to generate a "#define READINGS_NAME READINGS_CODE" for use in the command msg)
-- TYPE_NAME (join with NUMBER_TYPE table to get a numeric code for the type of number (e.g. unit32_t = 6)
--    See NUMBER_TYPE table.
-- FORMAT (Format to use for displaying the number)
-- FUNCTION_TYPE (join to FUNCTIONS.)  See FUNCTIONS table.
-- DESCRIPTION (Nonsense for the hapless Op and a crutch for the Wizard programmer; but must be unique)
--
-- READINGS_LIST differs from PARAM_LIST in how it is handled.
--
-- Readings are a retrieval of four bytes from some fixed memory location.
-- These locations typically have a counter, or some value being updated periodically.
--
-- The retrieval program uses a *fixed* pointer to scattered locations, whereas,
--   the PARAM_LIST will be accessed by a pointer to various locations where a table
--   of the values are stored.  The location of the pointer may change when parameters are updated, whereas,
--   the locations of the readings do not change.
--
-- Note: Some parameters may be changed in SRAM, e.g. offset and scale for one of the AD7799s, however the current
--   value being used in SRAM can be retrieved via the parameter list that loads the SRAM at startup or "revert".
--
DELETE FROM READINGS_LIST;
--                                    Reading name              Code   Type     format Function_type   Description
INSERT INTO READINGS_LIST VALUES ('TENSION_READ_FILTADC_THERM1' , 1, 'TYP_U32' ,'%u', 	 'TENSION_a', 'Tension: READING: double thrm[0]; Filtered ADC for Thermistor on AD7799');
INSERT INTO READINGS_LIST VALUES ('TENSION_READ_FILTADC_THERM2' , 2, 'TYP_U32' ,'%u',	 'TENSION_a', 'Tension: READING: double thrm[1]; Filtered ADC for Thermistor external');
INSERT INTO READINGS_LIST VALUES ('TENSION_READ_FORMCAL_THERM1' , 4, 'TYP_FLT' ,'%0.2f', 'TENSION_a', 'Tension: READING: double degX[0]; Formula computed thrm for Thermistor on AD7799');
INSERT INTO READINGS_LIST VALUES ('TENSION_READ_FORMCAL_THERM2' , 5, 'TYP_FLT' ,'%0.2f', 'TENSION_a', 'Tension: READING: double degX[1]; Formula computed thrm for Thermistor external');
INSERT INTO READINGS_LIST VALUES ('TENSION_READ_POLYCAL_THERM1' , 6, 'TYP_FLT' ,'%0.2f', 'TENSION_a', 'Tension: READING: double degC[0]; Polynomial adjusted degX for Thermistor on AD7799');
INSERT INTO READINGS_LIST VALUES ('TENSION_READ_POLYCAL_THERM2' , 7, 'TYP_FLT' ,'%0.2f', 'TENSION_a', 'Tension: READING: double degC[1]; Polynomial adjusted degX for Thermistor external');
INSERT INTO READINGS_LIST VALUES ('TENSION_READ_AD7799_LGR'     , 8, 'TYP_S32' ,'%u', 	 'TENSION_a', 'Tension: READING: int32_t lgr; last_good_reading (no filtering or adjustments)');
INSERT INTO READINGS_LIST VALUES ('TENSION_READ_AD7799_CALIB_1' , 9, 'TYP_FLT' ,'0.3f',  'TENSION_a', 'Tension: READING: ten_iircal[0];  AD7799 filtered (fast) and calibrated');
INSERT INTO READINGS_LIST VALUES ('TENSION_READ_AD7799_CALIB_2' ,10, 'TYP_FLT' ,'0.3f',  'TENSION_a', 'Tension: READING: ten_iircal[1];  AD7799 filtered (slow) and calibrated');
INSERT INTO READINGS_LIST VALUES ('TENSION_READ_CIC_RAW'        ,11, 'TYP_U32' ,'%u', 	 'TENSION_a', 'Tension: READING: int32_t cicraw; cic before averaging');
INSERT INTO READINGS_LIST VALUES ('TENSION_READ_CIC_AVE'        ,12, 'TYP_U32' ,'%u', 	 'TENSION_a', 'Tension: READING: int32_t cicave; cic averaged for determining offset');
INSERT INTO READINGS_LIST VALUES ('TENSION_READ_CIC_AVE_CT'     ,13, 'TYP_U32' ,'%u', 	 'TENSION_a', 'Tension: READING: int32_t ave.n;  current count for above average');



