-- PAYLOAD_TYPE Name of payload arrangement versus code number for calling a routine
--
-- PAYLOAD_TYPE_NAME varchar(24) PRIMARY KEY,
--  Name assigned to this payload layout
--
-- PAYLOAD_TYPE_CODE numeric(4) NOT NULL UNIQUE,
--  Code that associates with the name.
--
-- DESCRIPTION varchar(128) NOT NULL UNIQUE
--  Helpful words for the puzzled programmer
--
DELETE from PAYLOAD_TYPE;
--   payload -- [0] - [7]	(-- = conversion routine written for to/from payload: 'pay_type_cnvt.c')
--                      PAYLOAD_TYPE_NAME  PAYLOAD_TYPE_CODE    DESCRIPTION  ([] = payload array index)                   
INSERT INTO PAYLOAD_TYPE VALUES ('NONE',	 0,	' No payload bytes');
INSERT INTO PAYLOAD_TYPE VALUES ('FF',		 1,	' [0]-[3]: Full Float');			--
INSERT INTO PAYLOAD_TYPE VALUES ('FF_FF',	 2,	' [0]-[3]: Full Float[0]; [4]-[7]: Full Float[1]');	--
INSERT INTO PAYLOAD_TYPE VALUES ('U32',		 3,	' [0]-[3]: uint32_t');				--
INSERT INTO PAYLOAD_TYPE VALUES ('U32_U32',	 4,	' [0]-[3]: uint32_t[0]; [4]-[7]: uint32_t[1]');	--
INSERT INTO PAYLOAD_TYPE VALUES ('U8_U32',	 5,	' [0]: uint8_t; [1]-[4]: uint32_t');		--
INSERT INTO PAYLOAD_TYPE VALUES ('S32',		 6,	' [0]-[3]: int32_t');				--
INSERT INTO PAYLOAD_TYPE VALUES ('S32_S32',	 7,	' [0]-[3]: int32_t[0]; [4]-[7]: int32_t[1]');		--
INSERT INTO PAYLOAD_TYPE VALUES ('U8_S32',	 8,	' [0]: int8_t; [4]-[7]: int32_t');		--
INSERT INTO PAYLOAD_TYPE VALUES ('HF',		 9,	' [0]-[1]: Half-Float');			--
INSERT INTO PAYLOAD_TYPE VALUES ('F34F',	10,	' [0]-[2]: 3/4-Float');				--
INSERT INTO PAYLOAD_TYPE VALUES ('xFF',		11,	' [1]-[4]: Full-Float, first   byte  skipped');	--
INSERT INTO PAYLOAD_TYPE VALUES ('xxFF',	12,	' [1]-[4]: Full-Float, first 2 bytes skipped');	--
INSERT INTO PAYLOAD_TYPE VALUES ('xxU32',	13,	' [1]-[4]: uint32_t, first 2 bytes skipped');	--
INSERT INTO PAYLOAD_TYPE VALUES ('xxS32',	14,	' [1]-[4]: int32_t, first 2 bytes skipped');	--
INSERT INTO PAYLOAD_TYPE VALUES ('U8_U8_U32',	15,	' [0]:[1]:[2]-[5]: uint8_t[0],uint8_t[1],uint32_t,');	--
INSERT INTO PAYLOAD_TYPE VALUES ('U8_U8_S32',	16,	' [0]:[1]:[2]-[5]: uint8_t[0],uint8_t[1], int32_t,');	--
INSERT INTO PAYLOAD_TYPE VALUES ('U8_U8_FF',	17,	' [0]:[1]:[2]-[5]: uint8_t[0],uint8_t[1], Full Float,');--
INSERT INTO PAYLOAD_TYPE VALUES ('U16',		18,	' [0]:[1]:[2]uint16_t');			--
INSERT INTO PAYLOAD_TYPE VALUES ('S16',		19,	' [0]:[1]:[2] int16_t');			--



